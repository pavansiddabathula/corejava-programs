import java.util.Scanner;
public class Main{
    public int operand1;
    public int operand2;
    public int operand3;

    // Constructor to initialize operands
    public Main(int operand1, int operand2) {
        this.operand1 = operand1;
        this.operand2 = operand2;
    }
    public Main(int operand1, int operand2,int operand3) {
        this.operand1 = operand1;
        this.operand2 = operand2;
        this.operand3 = operand3;
    }

    // Method to perform addition
     public int add() {
        return operand1 + operand2;
    }
     public int add(int operand3 ) {
        return operand1 + operand2+ operand3;
    }


    // Method to perform subtraction
    public int subtract() {
        return operand1 - operand2;
    }

    // Method to perform multiplication
    public int multiply() {
        return operand1 * operand2;
    }

    // Method to perform division
    public double divide() {
        if (operand2 != 0) {
            return (double) operand1 / operand2;
        } else {
            System.out.println("Cannot divide by zero.");
            return Double.NaN; // Not a Number (NaN) to indicate an undefined result
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input for operand1
        System.out.print("Enter the first operand: ");
        int operand1 = scanner.nextInt();

        // Input for operand2
        System.out.print("Enter the second operand: ");
        int operand2 = scanner.nextInt();
        
         // Input for operand3
        System.out.print("Enter the third operand: ");
        int operand3 = scanner.nextInt();

        // Creating an object of ArithmeticOperations
        Main calculator = new Main(operand1, operand2);
        Main calculator1 = new Main(operand1, operand2,operand3);

        // Perform arithmetic operations
        System.out.println("three Sum: " + calculator1.add(operand3));
        System.out.println("Sum: " + calculator.add());
        System.out.println("Difference: " + calculator.subtract());
        System.out.println("Product: " + calculator.multiply());
        System.out.println("Quotient: " + calculator.divide());

        scanner.close();
    }
}
