import java.util.Scanner;

public class Main{
    
    public static void main(String args[]) {
        System.out.println("Enter the range for prime numbers");
        int st = input_method();
        int end = input_method();
        System.out.println("The prime series are :");
        for (int i = st; i < end; i++) {
            if (primenums(i) != 0) {
                System.out.print(" "+primenums(i));
            }
        }  
    }

    public static int input_method() {
        return new Scanner(System.in).nextInt();
    }

    public static int primenums(int n) {
        if(n<=1)
        {
            return 0;
        }
        for (int i = 2; i <= n/2; i++) {
            if (n % i == 0) {
                return 0;
            }
        }
        return n;
    }
}