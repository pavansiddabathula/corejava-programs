import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int n;
	    while(true)
	    {
	        System.out.println("Enter the number between 1 to 10:");
	        Scanner s =new Scanner(System.in) ;
	        n=s.nextInt();
	        if(n<1 ||n>10)
	           continue;
	        break;    
	    }
		System.out.println(n+"the given number is ");
	}
}
