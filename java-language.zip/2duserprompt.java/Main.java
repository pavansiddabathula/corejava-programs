import java.util.Scanner;
public class Main {
        public static int userprompt() {
        return Scanner(System.in).nextInt();
    }
    public static void inputarray(int[][] array) {
        int i, j;
        for (i = 0; i <array.length; i++) {
            for (j = 0; j <array.length; j++) {
                System.out.print("Enter the array elements in the position " + (i + 1) + "," + (j + 1) + ": ");
                array[i][j] = userprompt();
            }
        }
    }
    public static void printarray(int[][] array, int rows, int columns) {
        int i, j;
        for (i = 0; i < rows; i++) {
            for (j = 0; j < columns; j++) {
                System.out.print(array[i][j] + " ");
            }
            System.out.println();
        }
    }
    public static void main(String[] arg) {
        System.out.println("Enter the No. of Rows and columns:");
        int rows = userprompt();
        int columns = userprompt();
        int[][] array = new int[rows][columns];
        inputarray(array, rows, columns);
        System.out.println("Entered 2D array:");
        printarray(array, rows, columns);
    }
}
