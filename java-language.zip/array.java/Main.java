import java.util.Arrays;
public class Main
{
	public static void main(String[] args) {
	    int i;
	    int[] numbers={2,4,5,6,7,8};
	    int[] arr=new int[9];
	    String[] arr1=new String[3];
	    Arrays.fill(arr,3);
	    printarray(arr);
	    Arrays.fill(arr1,"hello");
	    System.out.println(Arrays.toString(arr1));
	    arrays(numbers);
	    printarray(numbers);
	}
	public static int[]  arrays(int[] numbers)
	{
	    numbers[0]=1;
	    numbers[1]=2;
	    return numbers;
	}
	public static void printarray(int[] numbers)
	{
	    int i;
	     for(i=((numbers.length)-1);i>=0;i--){
		  System.out.print(numbers[i]+" ");
	}
}
}
