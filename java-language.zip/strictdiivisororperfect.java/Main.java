import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int i, n,sum=0;
	    System.out.println("Enter the number:");
	    Scanner s =new Scanner(System.in);
	    n=s.nextInt();
	    for(i=1;i<=n/2;i++)
	    {
	        if(n%i==0)
	        {
	            sum+=i;
	        }
	    }
	    if(sum!=n)
		   System.out.println("not a strict divisor or strong number");
		else
		   System.out.println("the sum is equal to the given number it is strictly devisor or strong number");
	}
}
