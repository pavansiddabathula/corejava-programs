import java.util.Arrays;
public class Main
{
	public static void main(String[] args) {
	    int a=100;
	    System.out.println(sum(a,2,4));
		System.out.println(sum(2,4));
	    System.out.println(sum(2,4,5));
		System.out.println(sum(2,4,5,6));
	    System.out.println(sum(2,4,5,6,7));
	}
	public static int sum(int a,int... arrname)
	{
	    System.out.println(a);
	    int i,sum=0;
	    for(i=0;i<arrname.length;i++)
	    {
	        sum+=arrname[i];
	    }
	    return sum;
	}
}
