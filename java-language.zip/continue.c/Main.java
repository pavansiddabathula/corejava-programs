import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int i;
	    /*System.out.println("Enter the range of the number to print even number:");
	    Scanner s =new Scanner(System.in);
	    n=s.nextInt();
	    */
	    System.out.println("the odd numbers are :ln");
	    for(i=1;i<100;i++)
	    {
	        if(i%2!=0)
	        {
	         System.out.print(" "+i);
	        }
	    }    
	    
	   System.out.println("\n The odd numbers in reverse order are :");
	        for(i=100;i>1;i--)
	        {
    	        if(i%2!=0)
    	        {
    	            System.out.print(" "+i);
    	        }
    	     }
    	     System.out.println("the even numbers are :ln");
	    for(i=1;i<100;i++)
	    {
	        if(i%2==0)
	        {
	         System.out.print(" "+i);
	        }
	    }    
	    
	   System.out.println("\n The even numbers in reverse order are :");
	        for(i=100;i>1;i--)
	        {
    	        if(i%2==0)
    	        {
    	            System.out.print(" "+i);
    	        }
    	     }
    	 System.out.println("in another way");
    	 System.out.println("\n The even numbers in reverse order are :");
	        for(i=100;i>1;i-=2)
	        {
    	            System.out.print(" "+i);
    	       
    	     }
    	  System.out.println("\n The even numbers are :");
    	      for(i=2;i<=100;i+=2)
	        {
    	            System.out.print(" "+i);
    	       
    	     }
    	     System.out.println("\n The odds numbers in reverse order are :");
	        for(i=100;i>1;i-=1)
	        {
    	            System.out.print(" "+i);
    	       
    	     }
    	  System.out.println("\n The odds numbers are :");
    	      for(i=2;i>1;i+=1)
	        {
    	            System.out.print(" "+i);
    	       
    	     }
    	 
    	     
	   }
}
