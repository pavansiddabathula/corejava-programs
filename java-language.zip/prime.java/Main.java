import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int n,i,count=0;
	   	System.out.println("Enter a number to check wheather a prime or not :");
	   	Scanner s=new Scanner(System.in);
	   	n=s.nextInt();
	   	for(i=2;i<=n/2;i++)
	   	{
	   	    if(n%i==0)
	   	    {
	   	        count++;
	   	    }
	   	}
	   	if(count==0 && n>1)
	   	{
	   	  System.out.println("The given number "+n+" is a prime number");  
	   	}
	   	else
	   	{
	   	    System.out.println("The given number "+n+" is not a prime number");  
	   	}
	}
}
