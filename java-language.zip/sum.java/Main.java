import  java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int n,sum=0;
	    Scanner s=new Scanner(System.in);
	    //n=s.nextInt();
	    while(sum<=100){
	    System.out.println("Enterr a number:");
	    n=s.nextInt();
	    sum+=n;
	    }
	    System.out.println("Done:"+sum);
	}
}
