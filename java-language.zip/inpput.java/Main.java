/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    //System.out.println("Enter the name of the student");
	    Scanner s=new Scanner(System.in);
	    System.out.println("enter the number:");
	    int n1=s.nextInt();
	    n1++;
	    System.out.println(n1);
	    ++n1;
	    System.out.println(n1);
	    System.out.println(n1 +=n1);
	    //System.out.println(n1 -=n1);
	    System.out.println(n1 *=n1);
	    System.out.println(n1 /=n1);
	    System.out.println(n1 =n1+1);
	    System.out.println("Enter the name of the student");
	    String a=s.nextLine();
		System.out.println("Enter the age of the student:");
		int age=s.nextInt();
		System.out.println("Enter the Favorite Integer:");
	    int n=s.nextInt();
		System.out.println(n+" "+"is also my favorite Integer");
		System.out.println("The student name is :"+a);
		System.out.println("the age of the student is:"+age);
	}
}
