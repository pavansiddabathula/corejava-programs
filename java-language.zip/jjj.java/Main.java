public class Main {
    public static void main(String[] args) {
        int i = 0,a1, a;
        System.out.println("increment:");
        for (i = 0; i <=4;i++) {
            a =( ++i)+ 0;
            System.out.println("The pre-increment: " + a);
        }
         for (i = 0; i <=4;i++) {
            a1 =( i++)+ 0;
            System.out.println("The post-increment: " + a1);
        }
        for (i = 0; i <=4;++i) {
            a =( ++i)+ 0;
            System.out.println("The pre-increment: " + a);
        }
         for (i = 0; i <=4;++i) {
            a1 =( i++)+ 0;
            System.out.println("The post-increment: " + a1);
        }
        System.out.println("increment:");
        for (i = 10; i >=0;i--) {
            a =( --i)+ 0;
            System.out.println("The pre-Decrement: " + a);
        }
        
         for (i = 10; i>=0;i--) {
            a1 =( i--)+ 0;
            System.out.println("The post-Decrement: " + a1);
        }
        for (i = 10; i >=0;--i) {
            a =( --i)+ 0;
            System.out.println("The pre-Decrement: " + a);
        }
         for (i = 10; i >=0;--i) {
            a1 =( i--)+ 0;
            System.out.println("The post-Decrement: " + a1);
        }
    }
}

