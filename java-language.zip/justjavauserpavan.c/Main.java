import java.util.Scanner;
public class Main{
    public static void sayhi()
    {
        System.out.println("hello pavan sidhabathula");
        //Scanner s=new Scanner(System.in);
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the name :");
        int a=s.nextInt();
        int b=s.nextInt();
        System.out.println("the sum is :"+(a+b));
    }
    public static void main(String[] args)
    {
        sayhi();
        System.out.println("Hello World");
        
    }
}
