
public class Main
{
	public static void main(String[] args) {
	    byte a1=20;
	    short a2=499;
	    float a=19.0F;
	    long a3=46789877l;
	    System.out.println("Hello World");
	    System.out.println("the number is:"+a);
		System.out.println("Hello World");
		System.out.println(a3-a);
	    System.out.println(a-a3);
		System.out.println(a2-a);
        int x = 10;
        double y = 37888;
        String ab="";
        String str = "Hello";
        String str1=" Pavan kumar";
        char c=str.charAt(2);
        System.out.println(str.toUpperCase());
         System.out.println(str.toLowerCase());
         System.out.println(str);
         System.out.println(str.length());
         System.out.println(str.isEmpty());
         System.out.println(c);
         System.out.println(str.indexOf('e'));
         System.out.println(str+ " " +str1);
         System.out.println(str+ a+ 5);

        /*Using getClass() to get the type of variables
        System.out.println("Type of x: " + x.getClass().getName());
        System.out.println("Type of y: " + y.getClass().getName());
        System.out.println("Type of str: " + str.getClass().getName());
        */
    }
}



