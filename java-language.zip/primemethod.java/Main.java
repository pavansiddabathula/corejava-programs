import java.util.Scanner;
import java.util.*;
public class Main
{
    public int isprime(int n)
    {
        int i;
        if(n<2)
        {
            return 0;
        }
        for(i=2;i<n/2;i++)
        {
            if(n%i==0)
            {
                return 0;
            }
        }
        return 1;
        
    }
	public static void main(String[] args) {
	    int n;
		System.out.println("Enetr the number to check prime or not:");
		Scanner s =new Scanner(System.in);
		n=s.nextInt();
		Main a=new Main();
		//a.isprime(n)
	    if(a.isprime(n)!=1)
	    {
	       System.out.println("the given number " +n+ " is not a prime");
	    }
	    else{
	     System.out.println("the given number " +n+ " is a prime");   
	    }
	}
}
