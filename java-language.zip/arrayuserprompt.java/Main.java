import java.util.Arrays;
import java.util.Scanner;
import java.util.*;
public class Main
{

    public static int userprompt() {
        Scanner s = new Scanner(System.in);
        return s.nextInt();
    }
    public static void printarray(int[] array)
    {
        int i;
         for(i=0;i<array.length;i++)
        {
            System.out.println("Enter the array elements"+(i+1)+":"+array[i]);
        }
    }
    public static void inputarray(int[] array)
    {
        int i;
         for(i=0;i<array.length;i++)
        {
            System.out.println("Enter the array elements"+(i+1)+":");
            array[i]=userprompt();
        }
    }
    public static void main(String[] arg)
    {
        System.out.println("Enter the size of the array:");
        int size=userprompt();
        int i;
        int[] array = new int[size] ;
        inputarray(array);
        printarray(array);
        
    }
}    

