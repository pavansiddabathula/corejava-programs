import java.util.ArrayList;
import java.util.Scanner;
public class Main{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> num = new ArrayList<>();
        System.out.println("Enter the -1 if you want exit:");
        while(true)
        {
            int n;
            System.out.println("Enter the number:"); 
            n=scanner.nextInt();
            if(n==-1)
                break;
                
            num.add(n);
        }
       // num.add(n);
       System.out.println("the array list is:"); 
       for(int number:num)
       {
         System.out.println(number);
       } 
    }
        
}

