import java.util.Scanner;
public class Main{
    private int operand1;
    private int operand2;

    // Constructor without using 'this' keyword
    public Main(int operand1, int operand2) {
       this. operand1 = operand1;
       this. operand2 = operand2;
    }

    // Methods for arithmetic operations

    public int add() {
        return operand1 + operand2;
    }

    public int subtract() {
        return operand1 - operand2;
    }

    public int multiply() {
        return operand1 * operand2;
    }

    public double divide() {
        if (operand2 != 0) {
            return (double) operand1 / operand2;
        } else {
            System.out.println("Cannot divide by zero.");
            return Double.NaN;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first operand: ");
        int operand1 = scanner.nextInt();

        System.out.print("Enter the second operand: ");
        int operand2 = scanner.nextInt();

        // Creating an object of ArithmeticOperations without using 'this'
        Main calculator = new Main(operand1, operand2);

        System.out.println("Sum: " + calculator.add());
        System.out.println("Difference: " + calculator.subtract());
        System.out.println("Product: " + calculator.multiply());
        System.out.println("Quotient: " + calculator.divide());

        scanner.close();
    }
}

