public class Main
{
	public static void main(String[] args) {
	    my_name();
	    my_age();
	    String args1=args[0];
	System.out.println("Hello World");
		System.out.println(args1);
	}
	public static void my_name(){
	    String my_name="Siddabathula pavan Kumar" ;
	    System.out.println(my_name);
	    System.out.println((my_name));
	}
	public static void my_age(){
	    int my_age=20;
	    System.out.println("Age:"+my_age);
	    
	}
}
