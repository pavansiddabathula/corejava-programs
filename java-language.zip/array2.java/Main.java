import java.util.Arrays;
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int n;
		System.out.println("Enter the size of arrray:");
		Scanner s=new Scanner(System.in);
		n=s.nextInt();
		while(n<1|| n>20){
		   System.out.println("Enter the size of arrray:");
    	   n=s.nextInt();
		    }
		    int[] arr=new int[n];
		    System.out.print("Enter the array elements:");
		    fillarrayOfindex(arr);
		    print(arr);
		
	}
	public static void fillarrayOfindex(int [] arr)
	{
	    int i;
	    Scanner s = new Scanner(System.in);
	    for(i=0;i<arr.length;i++)
	    {
	        arr[i]=s.nextInt();
	    }
	}
	public static void print(int[] arr)
	{
	    int i;
	    System.out.println("the array elements:");
	    for(i=0;i<arr.length;i++)
	    {
	        System.out.print(arr[i]);
	    }
	   // System.out.println(Array.toString(arr));
	}
		 
}
