import java.util.*;
import java.util.ArrayList;
import java.util.Scanner;
public class Main{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for the number of rows and columns
        System.out.print("Enter the number of rows: ");
        int rows = scanner.nextInt();

        System.out.print("Enter the number of columns: ");
        int columns = scanner.nextInt();

        // Create an ArrayList of ArrayList to represent the matrix
        ArrayList<ArrayList<Integer>> matrix = new ArrayList<>();

        // Initialize the matrix
        for (int i = 0; i < rows; i++) {
            ArrayList<Integer> row = new ArrayList<>();
            for (int j = 0; j < columns; j++) {
                System.out.print("Enter the element at position [" + (i + 1) + "," + (j + 1) + "]: ");
                row.add(scanner.nextInt());
            }
            matrix.add(row);
        }

        // Display the matrix
        System.out.println("Matrix:");
        for (ArrayList<Integer> row : matrix) {
            for (int element : row) {
                System.out.print(element + " ");
            }
            System.out.println();
        }

        // Close the scanner
        scanner.close();
    }
}

